import java.util.Scanner;

public class RentalKendaraan23 {
    static TransaksiRental23[] transaksiRental23s = new TransaksiRental23[100];
    static int jumlahTransaksi = 0;
    static int kodeTransaksi = 1;
    static BarangRental23[] barangRental23s = {
        new BarangRental23("S 4567 YV", "Honda Beat", "Motor", 2017, 25000),
        new BarangRental23("N 4511 VS", "Honda Vario", "Motor", 2018, 25000),
        new BarangRental23("N 1453 AA", "Toyota Yaris", "Mobil", 2022, 40000),
        new BarangRental23("AB 4321 A", "Toyota Innova", "Mobil", 2019, 40000),
        new BarangRental23("B 1234 AG", "Toyota Avanza", "Mobil", 2021, 40000)
    };

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        boolean running = true;

        while (running) {
            System.out.println("Menu");
            System.out.println("1. Daftar Kendaraan");
            System.out.println("2. Peminjaman");
            System.out.println("3. Tampilkan seluruh transaksi");
            System.out.println("4. Urutkan Transaksi urut no TNKB");
            System.out.println("5. Keluar");
            System.out.print("Pilih(1-5): ");
            int pilihan = input.nextInt();
            input.nextLine(); // membersihkan newline

            switch (pilihan) {
                case 1:
                    tampilkanDaftarKendaraan();
                    break;

                case 2:
                    prosesPeminjaman(input);
                    break;

                case 3:
                    tampilkanTransaksi();
                    break;

                case 4:
                    urutkanTransaksi();
                    break;

                case 5:
                    running = false;
                    break;

                default:
                    System.out.println("Pilihan tidak valid. Silakan pilih angka antara 1-5.");
                    break;
            }
        }
        input.close();
    }

    public static void tampilkanDaftarKendaraan() {
        System.out.println("Daftar Kendaraan Rental Serba Serbi");
        System.out.println("+++++++++++++++++++++++++");
        System.out.println("| Nomor TNKB | Nama Kendaraan | Jenis | Tahun | Biaya Sewa Perjam |");
        System.out.println("+++++++++++++++++++++++++");
        for (BarangRental23 barangRental23 : barangRental23s) {
            System.out.printf("| %-10s | %-14s | %-5s | %-5d | %,d |\n",
                    barangRental23.getNoTNKB(),
                    barangRental23.getNamaKendaraan(),
                    barangRental23.getJenisKendaraan(),
                    barangRental23.getTahun(),
                    barangRental23.getBiayaSewa());
        }
        System.out.println("+++++++++++++++++++++++++");
    }

    public static void prosesPeminjaman(Scanner input) {
        System.out.println("Masukkan Data Peminjaman");
        System.out.print("Masukkan Nama Peminjam: ");
        String namaPeminjam = input.nextLine();
        System.out.print("Masukkan Nomer TNKB: ");
        String noTNKB = input.nextLine().trim();
        System.out.print("Masukkan Lama Pinjam (jam): ");
        int lamaPinjam = input.nextInt();
        input.nextLine(); // membersihkan newline
        System.out.print("Apakah Member (ya/tidak): ");
        String isMember = input.nextLine().toLowerCase();

        BarangRental23 barangRental = cariBarangRental(noTNKB);

        if (barangRental == null) {
            System.out.println("Kendaraan tidak ditemukan.");
        } else {
            if (!barangRental.isAvailable()) {
                System.out.println("Tidak bisa diproses, kendaraan sudah dipinjam.");
            } else {
                double totalBiaya = hitungTotalBiaya(lamaPinjam, barangRental, isMember);

                transaksiRental23s[jumlahTransaksi] = new TransaksiRental23(
                        kodeTransaksi, namaPeminjam, lamaPinjam, totalBiaya, barangRental);
                jumlahTransaksi++;
                kodeTransaksi++;
                System.out.println("Transaksi berhasil dibuat.");
                barangRental.setAvailable(false);
            }
        }
    }

    public static void tampilkanTransaksi() {
        System.out.println("Daftar Transaksi Peminjaman Rental Serba Serbi");
        System.out.println("+++++++++++++++++++++++++");
        System.out.println("| Kode | No TNKB  | Nama Barang   | Nama Peminjam | Lama Pinjam | Total Biaya |");
        for (int i = 0; i < jumlahTransaksi; i++) {
            TransaksiRental23 tr = transaksiRental23s[i];
            BarangRental23 br = tr.getBr();
            System.out.printf("| %-4d | %-8s | %-12s | %-13s | %-11d | %,-11.2f |\n", 
                              tr.getKodeTransaksi(), br.getNoTNKB(), br.getNamaKendaraan(), 
                              tr.getNamaPeminjam(), tr.getLamaPinjam(), tr.getTotalBiaya());
        }
        System.out.println("+++++++++++++++++++++++++");
        System.out.println("Semua transaksi berhasil dicetak");
        System.out.println("TOTAL PENDAPATAN RENTAL SERBA SERBI");
        System.out.println("Pendapatan hari ini: " + hitungTotalPendapatan());
    }

    public static void urutkanTransaksi() {
        if (jumlahTransaksi == 0) {
            System.out.println("Belum ada transaksi yang dilakukan.");
        } else {
            for (int i = 0; i < jumlahTransaksi - 1; i++) {
                for (int j = 0; j < jumlahTransaksi - i - 1; j++) {
                    if (transaksiRental23s[j].getBr().getNoTNKB().compareToIgnoreCase(transaksiRental23s[j + 1].getBr().getNoTNKB()) > 0) {
                        TransaksiRental23 temp = transaksiRental23s[j];
                        transaksiRental23s[j] = transaksiRental23s[j + 1];
                        transaksiRental23s[j + 1] = temp;
                    }
                }
            }

            System.out.println("Daftar Transaksi Peminjaman Rental Serba Serbi (diurutkan berdasarkan No TNKB)");
            System.out.println("+++++++++++++++++++++++++");
            System.out.println("| Kode | No TNKB | Nama Barang | Nama Peminjam | Lama Pinjam | Total Biaya |");
            for (int i = 0; i < jumlahTransaksi; i++) {
                TransaksiRental23 transaksiRental23 = transaksiRental23s[i];
                System.out.printf("| %-5d| %-10s| %-13s| %-14s| %-11d| %.2f |\n",
                        transaksiRental23.getKodeTransaksi(),
                        transaksiRental23.getBr().getNoTNKB(),
                        transaksiRental23.getBr().getNamaKendaraan(),
                        transaksiRental23.getNamaPeminjam(),
                        transaksiRental23.getLamaPinjam(),
                        transaksiRental23.getTotalBiaya());
            }
            System.out.println("+++++++++++++++++++++++++");
        }
    }

    public static BarangRental23 cariBarangRental(String noTNKB) {
        for (BarangRental23 br : barangRental23s) {
            if (br.getNoTNKB().equalsIgnoreCase(noTNKB)) {
                return br;
            }
        }
        return null;
    }

    public static double hitungTotalBiaya(int lamaPinjam, BarangRental23 barangRental, String isMember) {
        double totalBiaya = lamaPinjam * barangRental.getBiayaSewa();

        if (isMember.equals("ya")) {
            totalBiaya -= 25000;
        }

        if (lamaPinjam >= 48 && lamaPinjam <= 78) {
            totalBiaya *= 0.90; // diskon 10%
        } else if (lamaPinjam > 78) {
            totalBiaya *= 0.80; // diskon 20%
        }

        return totalBiaya;
    }

    public static double hitungTotalPendapatan() {
        double totalPendapatan = 0;
        for (int i = 0; i < jumlahTransaksi; i++) {
            totalPendapatan += transaksiRental23s[i].getTotalBiaya();
        }
        return totalPendapatan;
    }
}
