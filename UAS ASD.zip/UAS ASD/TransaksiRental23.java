public class TransaksiRental23 {
    public int kodeTransaksi;
    public String namaPeminjam;
    public int lamaPinjam;
    public double totalBiaya;
    public BarangRental23 br;

    public TransaksiRental23(int kodeTransaksi, String namaPeminjam, int lamaPinjam, double totalBiaya, BarangRental23 br) {
        this.kodeTransaksi = kodeTransaksi;
        this.namaPeminjam = namaPeminjam;
        this.lamaPinjam = lamaPinjam;
        this.totalBiaya = totalBiaya;
        this.br = br;
    }

    public int getKodeTransaksi() {
        return kodeTransaksi;
    }

    public String getNamaPeminjam() {
        return namaPeminjam;
    }

    public int getLamaPinjam() {
        return lamaPinjam;
    }

    public double getTotalBiaya() {
        return totalBiaya;
    }

    public BarangRental23 getBr() {
        return br;
    }
}
